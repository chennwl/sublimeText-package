var logMsg = "Hello, World!"
var var1, var2,
    var3, simpleVariable4;

console.log(logMsg);

var2 = "One more log message";
console.log(var2);

simpleVariable4 = "Info message from Node";
console.info(simpleVariable4, "\n");

console.info(new Date());
